// Native disclosures and anchors work independently of this enhancement layer.
// Signature Assembly: no timer, easing loop or transform on the central curve.
function initializeSignature() {
  const region = document.querySelector('.signature-assembly');
  if (!region || !('IntersectionObserver' in window)) return;
  const svg = region.querySelector('.signature-mark');
  const head = region.querySelector('.signature-head');
  const body = region.querySelector('.signature-body');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  let frame = 0, visible = false, needsMeasure = true;
  let start = 0, end = 1, distance = 0;
  function paint() {
    frame = 0;
    if (reduced.matches) {
      head.style.removeProperty('transform');
      body.style.removeProperty('transform');
      return;
    }
    if (needsMeasure) {
      const bounds = region.getBoundingClientRect();
      const center = bounds.top + scrollY + bounds.height / 2;
      const maximum = Math.max(0, document.documentElement.scrollHeight - innerHeight);
      start = Math.max(0, center - innerHeight * .9);
      end = Math.max(start + 1, Math.min(center - innerHeight * .5, maximum - 16));
      // SVG transforms use viewBox units: convert the requested CSS displacement.
      distance = parseFloat(getComputedStyle(region).getPropertyValue('--signature-distance')) * svg.viewBox.baseVal.width / svg.getBoundingClientRect().width;
      needsMeasure = false;
    }
    const progress = Math.max(0, Math.min(1, (scrollY - start) / (end - start)));
    const offset = ((1 - progress) * distance).toFixed(3);
    head.style.transform = `translateY(-${offset}px)`;
    body.style.transform = `translateY(${offset}px)`;
  }
  function schedule() {
    if (!frame && !document.hidden) frame = requestAnimationFrame(paint);
  }
  function measure() { needsMeasure = true; schedule(); }
  const observer = new IntersectionObserver(entries => {
    visible = entries[0].isIntersecting;
    // Paint the boundary position once on exit as well as on entry.
    schedule();
  }, {rootMargin:'100px 0px'});
  observer.observe(region);
  addEventListener('scroll', () => { if (visible && !reduced.matches) schedule(); }, {passive:true});
  addEventListener('resize', measure, {passive:true});
  addEventListener('load', measure, {once:true});
  if ('ResizeObserver' in window) new ResizeObserver(measure).observe(document.body);
  reduced.addEventListener('change', measure);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) measure(); });
  document.fonts?.ready.then(measure);
  measure();
}
initializeSignature();

const toggle = document.querySelector('.menu-toggle');
const menu = document.getElementById('mobile-menu');
const main = document.querySelector('main');
const footer = document.querySelector('footer');
// Move the same CTA, preserving its link, listeners and desktop position.
const mobileComposition = matchMedia('(max-width: 640px)');
const careCopy = document.querySelector('.care-copy');
const careLayout = document.querySelector('.care-layout');
const careCTA = careCopy.querySelector('.button');
function arrangeCare() {
  (mobileComposition.matches ? careLayout : careCopy).append(careCTA);
}
arrangeCare();
mobileComposition.addEventListener('change', arrangeCare);
function closeMenu(restoreFocus = false) {
  menu.hidden = true;
  toggle.setAttribute('aria-expanded', 'false');
  document.body.style.overflow = '';
  main.inert = false;
  footer.inert = false;
  if (restoreFocus) toggle.focus();
}
toggle.addEventListener('click', () => {
  if (!menu.hidden) return closeMenu(true);
  menu.hidden = false;
  toggle.setAttribute('aria-expanded', 'true');
  document.body.style.overflow = 'hidden';
  main.inert = true;
  footer.inert = true;
});
menu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => closeMenu(true)));
document.addEventListener('keydown', event => {
  if (menu.hidden) return;
  if (event.key === 'Escape') closeMenu(true);
  if (event.key === 'Tab') {
    const controls = [toggle, ...menu.querySelectorAll('a')];
    const first = controls[0], last = controls.at(-1);
    if (event.shiftKey && document.activeElement === first) {event.preventDefault(); last.focus();}
    else if (!event.shiftKey && document.activeElement === last) {event.preventDefault(); first.focus();}
  }
});
window.addEventListener('resize', () => {if (innerWidth > 1000 && !menu.hidden) closeMenu();});
document.getElementById('year').textContent = new Date().getFullYear();
const privacy = document.getElementById('privacy');
document.getElementById('privacy-open').addEventListener('click', () => privacy.showModal());
document.getElementById('privacy-close').addEventListener('click', () => privacy.close());
privacy.addEventListener('click', event => {
  const rect = privacy.getBoundingClientRect();
  if (event.target === privacy && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) privacy.close();
});
const header = document.querySelector('header');
let headerScrolled = null;
function updateHeader() {
  const next = scrollY > 24;
  if (next !== headerScrolled) {
    headerScrolled = next;
    header.classList.toggle('scrolled', next);
  }
}
window.addEventListener('scroll', updateHeader, {passive: true});
updateHeader();

const marqueeToggle = document.querySelector('.marquee-toggle');
const track = document.querySelector('.marquee-track');
marqueeToggle.addEventListener('click', () => {
  const paused = track.classList.toggle('paused');
  marqueeToggle.setAttribute('aria-pressed', String(paused));
  marqueeToggle.innerHTML = paused ? 'Retomar movimento <span aria-hidden="true">▷</span>' : 'Pausar movimento <span aria-hidden="true">Ⅱ</span>';
});
const shimmerButton = document.querySelector('.button--shimmer');
let marqueeVisible = false;
let shimmerVisible = false;
const goldenFlow = document.querySelector('.gold-flow');
let heroVisible = false;
function syncEffects() {
  track.classList.toggle('offscreen', !marqueeVisible || document.hidden);
  shimmerButton?.classList.toggle('effect-visible', shimmerVisible && !document.hidden);
  goldenFlow?.classList.toggle('effect-paused', !heroVisible || document.hidden);
}
const effectObserver = new IntersectionObserver(entries => {
  for (const entry of entries) {
    if (entry.target === track.parentElement) marqueeVisible = entry.isIntersecting;
    if (entry.target === shimmerButton) shimmerVisible = entry.isIntersecting;
    if (entry.target === goldenFlow) heroVisible = entry.isIntersecting;
  }
  syncEffects();
});
effectObserver.observe(track.parentElement);
if (shimmerButton) effectObserver.observe(shimmerButton);
if (goldenFlow) effectObserver.observe(goldenFlow);
document.addEventListener('visibilitychange', syncEffects);
syncEffects();

const activeLinks = document.querySelectorAll('header nav a');
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    activeLinks.forEach(link => {
      if (link.hash === '#' + entry.target.id) link.setAttribute('aria-current', 'location');
      else link.removeAttribute('aria-current');
    });
  });
}, {rootMargin: '-20% 0px -60% 0px'});
document.querySelectorAll('main section[id]').forEach(section => observer.observe(section));
document.querySelector('a[href="#formacao"]').addEventListener('click', () => {
  document.getElementById('formacao').focus({preventScroll: true});
});

// Animate only the button under a fine pointer; read its bounds once on entry.
const magneticMedia = matchMedia('(min-width: 641px) and (hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)');
const magnets = [...document.querySelectorAll('.button--magnetic')].map(element => ({element, x:0, y:0, tx:0, ty:0}));
let activeMagnet = null;
let magneticFrame = 0;
function paintMagnet() {
  const item = activeMagnet;
  if (!item) {magneticFrame = 0; return;}
  item.x += (item.tx - item.x) * .16;
  item.y += (item.ty - item.y) * .16;
  const moving = Math.abs(item.x - item.tx) + Math.abs(item.y - item.ty) > .03;
  if (!moving) {item.x = item.tx; item.y = item.ty;}
  item.element.style.setProperty('--magnet-x', item.x.toFixed(2) + 'px');
  item.element.style.setProperty('--magnet-y', item.y.toFixed(2) + 'px');
  if (moving) magneticFrame = requestAnimationFrame(paintMagnet);
  else {
    magneticFrame = 0;
    if (!item.tx && !item.ty) {
      item.element.style.removeProperty('--magnet-x');
      item.element.style.removeProperty('--magnet-y');
      activeMagnet = null;
    }
  }
}
function scheduleMagnet() {
  if (activeMagnet && !magneticFrame) magneticFrame = requestAnimationFrame(paintMagnet);
}
function releaseMagnet() {
  if (!activeMagnet) return;
  activeMagnet.tx = activeMagnet.ty = 0;
  scheduleMagnet();
}
magnets.forEach(item => {
  item.element.addEventListener('pointerenter', event => {
    if (!magneticMedia.matches || event.pointerType !== 'mouse') return;
    if (activeMagnet && activeMagnet !== item) {
      activeMagnet.element.style.removeProperty('--magnet-x');
      activeMagnet.element.style.removeProperty('--magnet-y');
      activeMagnet.x = activeMagnet.y = activeMagnet.tx = activeMagnet.ty = 0;
    }
    activeMagnet = item;
    item.bounds = item.element.getBoundingClientRect();
  }, {passive:true});
  item.element.addEventListener('pointermove', event => {
    if (activeMagnet !== item || event.pointerType !== 'mouse') return;
    const rect = item.bounds;
    item.tx = Math.max(-4, Math.min(4, (event.clientX - rect.left - rect.width / 2) * .055));
    item.ty = Math.max(-3, Math.min(3, (event.clientY - rect.top - rect.height / 2) * .075));
    scheduleMagnet();
  }, {passive:true});
  item.element.addEventListener('pointerleave', releaseMagnet, {passive:true});
  item.element.addEventListener('pointercancel', releaseMagnet, {passive:true});
});
window.addEventListener('blur', releaseMagnet);
window.addEventListener('scroll', releaseMagnet, {passive:true});
magneticMedia.addEventListener('change', () => {
  cancelAnimationFrame(magneticFrame);
  magneticFrame = 0;
  activeMagnet = null;
  magnets.forEach(item => {
    item.x = item.y = item.tx = item.ty = 0;
    item.element.style.removeProperty('--magnet-x');
    item.element.style.removeProperty('--magnet-y');
  });
});
document.querySelectorAll('.button--magnetic,.button--liquid').forEach(button => {
  let feedbackTimer = 0;
  const clearFeedback = () => {clearTimeout(feedbackTimer);button.classList.remove('touch-feedback');};
  button.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse') return;
    clearTimeout(feedbackTimer);
    button.classList.add('touch-feedback');
  }, {passive:true});
  button.addEventListener('pointerup', () => {
    feedbackTimer = setTimeout(clearFeedback, 160);
  }, {passive:true});
  button.addEventListener('pointercancel', clearFeedback, {passive:true});
  button.addEventListener('pointerleave', clearFeedback, {passive:true});
});

// Photo depth: one passive scroll scheduler and only currently visible photographs.
const motionReduced = matchMedia('(prefers-reduced-motion: reduce)');
const motionFine = matchMedia('(hover: hover) and (pointer: fine)');
const modestDevice = !motionFine.matches || (navigator.deviceMemory && navigator.deviceMemory <= 4);
const depthPhotos = [
  ['.hero-photo', 'picture'],
  ['.about-image', 'picture'],
  ['.care-image', 'img']
].map(([selector, inner]) => {
  const frame = document.querySelector(selector);
  return {frame, image:frame.querySelector(inner), bounds:null, pointerFrame:0, rx:0, ry:0};
});
const visiblePhotos = new Set();
let parallaxFrame = 0;
function paintParallax() {
  parallaxFrame = 0;
  if (motionReduced.matches || document.hidden) return;
  const distance = modestDevice ? 7 : 18;
  for (const item of visiblePhotos) {
    if (innerWidth <= 640 && item.frame.matches('.care-image')) continue;
    const rect = item.frame.getBoundingClientRect();
    const progress = Math.max(-1, Math.min(1, (innerHeight / 2 - rect.top - rect.height / 2) / (innerHeight / 2 + rect.height / 2)));
    item.image.style.setProperty('--parallax-y', (-progress * distance).toFixed(1) + 'px');
  }
}
function scheduleParallax() {
  if (visiblePhotos.size && !parallaxFrame && !motionReduced.matches && !document.hidden) parallaxFrame = requestAnimationFrame(paintParallax);
}
const photoObserver = new IntersectionObserver(entries => {
  for (const entry of entries) {
    const item = depthPhotos.find(photo => photo.frame === entry.target);
    if (entry.isIntersecting) visiblePhotos.add(item);
    else visiblePhotos.delete(item);
    item.frame.classList.toggle('is-motion-visible', entry.isIntersecting && !motionReduced.matches && !document.hidden);
  }
  scheduleParallax();
}, {rootMargin:'60px 0px'});
depthPhotos.forEach(item => {
  item.frame.classList.add('photo-depth');
  photoObserver.observe(item.frame);
  const resetDepth = () => {
    cancelAnimationFrame(item.pointerFrame);
    item.pointerFrame = 0;
    item.bounds = null;
    item.rx = item.ry = 0;
    item.image.style.removeProperty('--depth-x');
    item.image.style.removeProperty('--depth-y');
  };
  item.frame.addEventListener('pointerenter', event => {
    if (motionFine.matches && event.pointerType === 'mouse' && !motionReduced.matches) item.bounds = item.frame.getBoundingClientRect();
  }, {passive:true});
  item.frame.addEventListener('pointermove', event => {
    if (!item.bounds || event.pointerType !== 'mouse' || motionReduced.matches) return;
    item.rx = (0.5 - (event.clientY - item.bounds.top) / item.bounds.height) * 3.5;
    item.ry = ((event.clientX - item.bounds.left) / item.bounds.width - 0.5) * 5;
    if (!item.pointerFrame) item.pointerFrame = requestAnimationFrame(() => {
      item.pointerFrame = 0;
      item.image.style.setProperty('--depth-x', item.rx.toFixed(2) + 'deg');
      item.image.style.setProperty('--depth-y', item.ry.toFixed(2) + 'deg');
    });
  }, {passive:true});
  item.frame.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' || motionReduced.matches || (innerWidth <= 640 && item.frame.matches('.care-image'))) return;
    item.image.style.setProperty('--depth-x', '1.2deg');
    item.image.style.setProperty('--depth-y', '-1.4deg');
  }, {passive:true});
  item.frame.addEventListener('pointerleave', resetDepth, {passive:true});
  item.frame.addEventListener('pointerup', resetDepth, {passive:true});
  item.frame.addEventListener('pointercancel', resetDepth, {passive:true});
  item.resetDepth = resetDepth;
});
window.addEventListener('scroll', scheduleParallax, {passive:true});
window.addEventListener('resize', scheduleParallax, {passive:true});
document.addEventListener('visibilitychange', () => {
  depthPhotos.forEach(item => item.frame.classList.toggle('is-motion-visible', visiblePhotos.has(item) && !motionReduced.matches && !document.hidden));
  scheduleParallax();
});
motionReduced.addEventListener('change', () => {
  cancelAnimationFrame(parallaxFrame);
  parallaxFrame = 0;
  depthPhotos.forEach(item => {
    item.resetDepth();
    item.image.style.removeProperty('--parallax-y');
    item.frame.classList.toggle('is-motion-visible', visiblePhotos.has(item) && !motionReduced.matches);
  });
  scheduleParallax();
});

// Progressive scroll reveal: the page remains readable if this script fails or motion is reduced.
const revealGroups = [
  '#sobre .about-copy > .eyebrow, #sobre .about-copy > h2, #sobre .about-copy > p:not(.eyebrow), #sobre .profile-facts, #sobre .about-copy > .button',
  '#atuacao .practice-layout > div:first-child',
  '#atuacao .practice-card',
  '#filosofia .care-copy > .eyebrow, #filosofia .care-copy > h2, #filosofia .care-copy > p:not(.eyebrow), #filosofia .button',
  '#filosofia blockquote',
  '#trajetoria .trajectory-copy > .eyebrow, #trajetoria .trajectory-copy > h2, #trajetoria .trajectory-copy > p:not(.eyebrow), #trajetoria .trajectory-copy > .button',
  '#formacao li',
  '#contato h2, #contato .button'
];
const revealObserver = new IntersectionObserver(entries => {
  for (const entry of entries) {
    if (!entry.isIntersecting) continue;
    entry.target.classList.add('is-visible');
    revealObserver.unobserve(entry.target);
  }
}, {threshold:0.08, rootMargin:'0px 0px -7% 0px'});
for (const group of revealGroups) {
  [...document.querySelectorAll(group)].forEach((element,index) => {
    element.classList.add('reveal-item');
    element.style.setProperty('--reveal-delay', Math.min(index * 85, 340) + 'ms');
    revealObserver.observe(element);
  });
}
document.documentElement.classList.add('motion-ready');

// Tilt each practice card around its own center; touch gives brief press feedback.
document.querySelectorAll('.practice-card').forEach(card => {
  let bounds = null;
  let tiltFrame = 0;
  let pendingX = 0, pendingY = 0;
  let cleanupTimer = 0;
  function paintTilt() {
    tiltFrame = 0;
    card.style.setProperty('--tilt-x', pendingX.toFixed(2) + 'deg');
    card.style.setProperty('--tilt-y', pendingY.toFixed(2) + 'deg');
  }
  function scheduleTilt() {
    if (!tiltFrame) tiltFrame = requestAnimationFrame(paintTilt);
  }
  function resetTilt() {
    bounds = null;
    pendingX = pendingY = 0;
    scheduleTilt();
    clearTimeout(cleanupTimer);
    cleanupTimer = setTimeout(() => card.classList.remove('is-tilting'), 400);
  }
  card.addEventListener('pointerenter', event => {
    if (!motionFine.matches || event.pointerType !== 'mouse' || motionReduced.matches) return;
    clearTimeout(cleanupTimer);
    bounds = card.getBoundingClientRect();
    card.classList.add('is-tilting');
  }, {passive:true});
  card.addEventListener('pointermove', event => {
    if (!bounds || event.pointerType !== 'mouse' || motionReduced.matches) return;
    pendingX = (0.5 - (event.clientY - bounds.top) / bounds.height) * 12;
    pendingY = ((event.clientX - bounds.left) / bounds.width - 0.5) * 12;
    scheduleTilt();
  }, {passive:true});
  card.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' || motionReduced.matches) return;
    clearTimeout(cleanupTimer);
    card.classList.add('is-tilting');
    pendingX = 2.5;
    pendingY = -3;
    scheduleTilt();
  }, {passive:true});
  card.addEventListener('pointerleave', resetTilt, {passive:true});
  card.addEventListener('pointerup', resetTilt, {passive:true});
  card.addEventListener('pointercancel', resetTilt, {passive:true});
  motionReduced.addEventListener('change', resetTilt);
});
