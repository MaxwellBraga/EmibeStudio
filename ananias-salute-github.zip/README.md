# Ananias Salute — site institucional

Site estático em HTML, CSS e JavaScript, com fontes e imagens locais. Não exige instalação de dependências ou build.

## Enviar ao GitHub

1. Extraia este ZIP no computador.
2. Crie ou abra o repositório de destino.
3. Envie o conteúdo extraído mantendo a estrutura das pastas. Não envie apenas o ZIP: index.html precisa estar na raiz do repositório.
4. Em uploads pelo navegador, confira também o arquivo oculto .gitignore. Nunca envie credenciais reais.

## Visualização e hospedagem

Abra index.html para visualizar a interface. Para o formulário funcionar, publique o repositório na Netlify (com Functions) ou Vercel. O projeto não tem comando de build. GitHub Pages pode exibir a parte estática, mas não executa a API do formulário.

Leia CONFIGURAR-CONTATO.md para configurar as variáveis privadas no provedor e homologar o envio. O envio real ainda está pendente; nenhum endereço oficial ou chave foi inventado.

## Estrutura

- index.html: página principal.
- Arquivos CSS e JS: estilos e interações.
- assets/: fotografias, logo e fontes utilizados.
- server/contact.cjs: validação e integração do contato.
- api/contact.js: adaptador Vercel.
- netlify/functions/contact.cjs: adaptador Netlify.
- netlify.toml e vercel.json: configurações de hospedagem.
- .env.example: referência sem segredos.

O aviso fixo de prévia foi preservado. Os textos do FAQ aguardam aprovação da cliente. Licenças e créditos estão incluídos.
