'use strict';
const {handleContact}=require('../../server/contact.cjs');
exports.handler=async function contact(event){
 const h=event.headers||{};
 const answer=await handleContact({method:event.httpMethod,origin:h.origin,contentType:h['content-type'],ip:h['x-nf-client-connection-ip']||'unknown',idempotencyKey:h['idempotency-key'],body:event.isBase64Encoded?Buffer.from(event.body||'','base64').toString('utf8'):event.body});
 return {statusCode:answer.status,headers:answer.headers,body:JSON.stringify(answer.body)};
};
