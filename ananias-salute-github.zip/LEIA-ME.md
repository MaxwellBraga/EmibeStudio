# Site Dra. Taciana Annanias

## Signature Scroll Assembly — 09/10/2026

- Assinatura decorativa integrada à área verde do CTA final, imediatamente antes do rodapé. Somente o símbolo, sem palavras, em bege acetinado.
- SVG inline extraído dos contornos coloridos de `assets/logo-oficial.png`: cabeça, curva central e corpo independentes. Comparação de silhuetas com o PNG original: interseção sobre união de 99,98%; simplificação dos contornos limitada a 0,5 pixel na resolução original. A logo do header permanece intacta.
- A cabeça e o corpo se deslocam somente na vertical, até 35 px no desktop, 26 px no tablet e 18 px no mobile. A curva central não recebe estilos de transformação nem alterações de opacidade.
- O progresso deriva da rolagem real, é reversível e termina antes que o símbolo saia da tela. Um único `requestAnimationFrame` é agendado por atualização; não existem timers, loops ou bibliotecas para esta assinatura. A geometria é recalculada somente quando necessário.
- Símbolo de 112 px no desktop, 96 px no tablet e 80 px no celular. A área reservada comporta as peças separadas sem sobreposição com o CTA ou o rodapé.
- Com JavaScript desativado, ausência de suporte ao observador ou movimento reduzido, a assinatura é exibida montada e estática. Elemento decorativo com `aria-hidden` e SVG sem foco.
- Testes em Chrome nas larguras 320, 360, 375, 390, 430, 768, 1024 e 1440 px: direção, proporcionalidade, reversão, centro imóvel, posição estável com scroll parado, movimento reduzido, fallback estático, centralização e ausência de overflow. Gestos de toque nativos emulados também verificados nos dois sentidos.
- A validação usa uma origem HTTP simulada por arquivos locais. Safari iOS e aparelhos físicos Android/iPhone não foram testados nesta sessão.

## Narrativa institucional e fotografia de grupo — 09/10/2026

- Sobre recebeu a etiqueta “Além da gestão”, o título e os dois parágrafos fornecidos pela cliente. “Cuidar bem também é saber gerir.” aparece como conceito institucional, sem atribuição pessoal.
- A fotografia de blazer preto, as informações profissionais e o botão original foram preservados. O retrato ocupa espaço próprio no Grid para acompanhar a narrativa sem sobreposição.
- Formação e Trajetória agora exibe a fotografia de grupo fornecida pela cliente, com o enquadramento integral, bordas discretas, dimensões explícitas, lazy loading e três variantes WebP. A máscara lateral do retrato antigo foi removida para preservar os participantes.
- Validação no Chrome em 320, 390, 768, 1024 e 1440 px: imagens carregadas, proporção da foto de grupo preservada, sem erros de console, sobreposição ou rolagem horizontal. HTML das demais seções, fotografia de Sobre e links comparados com a versão anterior e preservados.
- A validação usou uma origem HTTP simulada por interceptação de arquivos locais, sem acesso à rede. Não é um teste em aparelhos físicos. O projeto estático não exige compilação; o pacote de produção é validado por integridade e presença dos arquivos referenciados.

## Refinamento mobile e Golden Flow — 09/10/2026

- Quatro curvas SVG douradas animadas na Hero desktop; duas curvas mais discretas no celular, com ciclos de 21–30 segundos. Pausam fora da tela/aba e respeitam movimento reduzido.
- Até 640 px, fotografia e texto da Hero compartilham a mesma área do Grid. O rosto fica acima do título, com gradiente de contraste sobre o corpo; a máscara inferior acompanha a proporção real da fotografia.
- Separadores mobile usam a mesma curva SVG de altura constante, independente da altura das seções.
- No celular, Cuidado e Gestão apresenta texto, frase, fotografia completa e o botão original. O mesmo botão volta à posição desktop quando a janela é ampliada.
- A composição desktop, as fotografias oficiais, os links e os seis efeitos existentes foram preservados. Nenhuma dependência foi adicionada.
- Validação desta entrega: navegador Chrome nas larguras 320, 360, 375, 390, 414, 430, 768, 820, 1024, 1280, 1440 e 1920 px; menu, teclado, âncoras, movimento reduzido e imagens. Testes em emulação, não em aparelhos físicos Android/iPhone.
- Este projeto é estático: não possui compilador ou comando de build. O pacote de produção reúne os arquivos efetivamente referenciados e verifica sua integridade.
- Nesta rodada, o ambiente bloqueou o servidor HTTP de teste; a inspeção visual usou arquivos locais no navegador. Lighthouse/axe não estão instalados. Não há novas notas Lighthouse, medições de INP ou métricas de campo; resultados de desempenho anteriores não são medições desta versão.
- O ZIP foi extraído e também validado em origem HTTP simulada por interceptação local do Playwright, sem conexão de rede: imagens e fontes carregadas, sem erros de console, em 1440 × 900 e 390 × 844.

Atualização da base estática existente em taciana-netlify-premium-3d.zip. Mantém HTML, CSS e JavaScript sem novas dependências de execução.

## Visualizar

Abra index.html no navegador ou acesse http://127.0.0.1:8765/ enquanto a prévia local estiver em execução. Para hospedar no Netlify, envie o conteúdo desta pasta ou o ZIP entregue; index.html precisa ficar na raiz. Não há comando de build.

## Arquivos alterados

- index.html: estrutura aprovada, textos, fotografias, navegação e CTAs; removida a seção de conteúdo e o carregamento da escultura 3D.
- editorial.css: composição desktop, paleta, fontes, tipografia, transições orgânicas e componentes.
- premium.css: composições para tablet e mobile, incluindo menu e enquadramentos.
- interactions.js: preservados menu e privacidade, com breakpoint atualizado, foco, navegação ativa e controle do marquee.
- creditos-fotograficos.txt: origem dos recursos utilizados.

## Arquivos adicionados

- fonts.css e assets/font-0.woff2, font-1.woff2, font-2.woff2: Cormorant Garamond e Manrope servidas localmente.
- assets/hero-oficial-480.webp e hero-oficial-800.webp: versões otimizadas da fotografia oficial de braços cruzados.
- assets/*-referencia.webp: recortes das fotografias presentes na imagem de referência fornecida.
- assets/logo-oficial.png: arquivo oficial anexado, preservado sem alterações.
- Licenças das fontes e este documento.

Atualização posterior: acrescentadas as três versões assets/apresentacao-oficial-640.webp, apresentacao-oficial-960.webp e apresentacao-oficial-1254.webp. Consulte REFINAMENTO.md para o mapeamento final e a comparação visual.

## Recursos que precisam de arquivos finais

A imagem de referência tem 992 × 1586 px. Os retratos sentada de blazer preto e de blazer branco, além das três fotografias dos cards, estão disponíveis apenas dentro dessa referência. Os recortes usados preservam a composição e os rostos, mas têm nitidez limitada em telas grandes. Substitua esses cinco WebPs pelos originais correspondentes quando estiverem disponíveis, preservando nomes e enquadramentos. A apresentação agora usa a fotografia oficial 25629267-e423-42d0-afbe-48770e53cf39.png em três versões WebP; o gesto da fotografia original difere do mockup.

O PNG oficial da logo contém o quadriculado incorporado aos pixels (RGB, sem transparência). Foi preservado em assets/logo-oficial.png; a interface usa a versão transparente da mesma marca que já estava no projeto, assets/ananias-salute-branca.png. Para acabamento definitivo, fornecer SVG ou PNG oficial com transparência real.

## Contato

Mantido o Instagram profissional que já constava na base: https://www.instagram.com/drataciana.annanias/. O botão de agendamento abre esse perfil para conversar; não há sistema de reserva. WhatsApp e e-mail seguem sinalizados como pendentes de confirmação. Nenhum contato ou resultado foi inventado.

## Verificação

Verificado em Chromium nas larguras 360, 390, 430, 768, 1024 e 1440 px: ausência de rolagem horizontal, imagens e fontes carregadas, âncoras válidas, menu mobile com Escape, diálogo de privacidade, controle de pausa do marquee e prefers-reduced-motion. A prévia não foi publicada.

Atualização de Sobre: aplicada a imagem Retrato profissional feminino em fundo transparente.png, conforme solicitação da cliente. A foto sentada deixou de ser necessária. Verificadas a imagem e a ausência de rolagem horizontal em 390 e 1440 px.

## Otimização de desempenho

- A logo da interface agora usa variantes WebP sem perda de 280 e 560 px; o PNG anterior permanece como fallback e arquivo original.
- Hero e Sobre usam variantes AVIF com transparência, derivadas dos PNGs oficiais, com os WebPs anteriores como fallback. A Hero mantém `fetchpriority="high"` e carregamento imediato; as fotografias seguintes continuam com lazy loading e dimensões explícitas.
- O efeito magnético lê a posição apenas do botão sob o ponteiro e interrompe seu `requestAnimationFrame` ao estabilizar. Marquee e brilho do CTA pausam fora da tela ou quando a aba está oculta. `prefers-reduced-motion` permanece respeitado.
- As três fontes efetivamente carregadas continuam em WOFF2 local com `font-display: swap`; apenas os pesos normais críticos são pré-carregados. Não foram adicionadas dependências.
- `sculpture.js` e recursos antigos não referenciados foram preservados na pasta de trabalho, mas omitidos do pacote de produção. Isso não modifica a página em execução.
- Medições locais com Chrome headless, servidor HTTP temporário e CPU simulada em 4× estão em `performance-antes.json` e `performance-depois.json`, junto ao pacote entregue. São testes de laboratório sem latência de rede, não pontuações Lighthouse ou Core Web Vitals de usuários reais.

## Efeitos interativos

- Magnetic Buttons com revelação de seta, Liquid Fill e Gold Shimmer já faziam parte da interface; foram preservados e testados. O toque agora recebe feedback explícito nos botões magnéticos e no preenchimento líquido.
- Hero, Sobre e apresentação receberam parallax de rolagem com leve profundidade ao ponteiro. No mobile a amplitude é menor; a apresentação fica estática nessa largura para evitar bordas expostas.
- Títulos, textos, informações e cards abaixo da primeira dobra entram com Scroll Reveal e atrasos escalonados. A Hero não é ocultada na carga inicial, preservando sua prioridade de exibição.
- Os três cards de atuação inclinam em 3D no mouse e respondem brevemente ao toque. O movimento usa `transform` e cessa após a interação.
- Todos os movimentos são simplificados ou desativados por `prefers-reduced-motion`; o conteúdo permanece visível sem JavaScript.
