// Native buttons provide keyboard activation; without JS all FAQ answers remain readable.
const faqItems=[...document.querySelectorAll('.faq-item')];
function setFAQ(item,open){
 item.classList.toggle('is-open',open);
 item.querySelector('.faq-question').setAttribute('aria-expanded',String(open));
 item.querySelector('.faq-symbol').textContent=open?'−':'+';
 const panel=item.querySelector('.faq-answer');
 panel.inert=!open;
 panel.setAttribute('aria-hidden',String(!open));
}
faqItems.forEach(item=>{
 setFAQ(item,false);
 item.querySelector('.faq-question').addEventListener('click',()=>{
  const open=!item.classList.contains('is-open');
  faqItems.forEach(other=>setFAQ(other,other===item&&open));
 });
});
document.documentElement.classList.add('faq-ready');
document.querySelector('.form-privacy-open').addEventListener('click',()=>document.getElementById('privacy').showModal());

const contactForm=document.getElementById('contact-form');
const sendButton=contactForm.querySelector('[type="submit"]');
const sendLabel=sendButton.querySelector('.button-label');
const formStatus=document.getElementById('contact-status');
const availability=document.getElementById('contact-availability');
const phoneInput=document.getElementById('contact-phone');
let ready=false,inFlight=false,startedAt=Date.now(),pendingPayload='',pendingKey='';
function setStatus(text,state=''){formStatus.textContent=text;formStatus.dataset.state=state;}
function phoneDigits(value){let d=value.replace(/\D/g,'');if(d.length>11&&d.startsWith('55'))d=d.slice(2);return d.slice(0,11);}
function formatPhone(value){const d=phoneDigits(value);if(!d)return '';if(d.length<=2)return '('+d;const local=d.slice(2),cut=local.length>8?5:4;return '('+d.slice(0,2)+') '+local.slice(0,cut)+(local.length>cut?'-'+local.slice(cut):'');}
function validatePhone(){const d=phoneDigits(phoneInput.value);phoneInput.setCustomValidity(/^([1-9]{2})([2-9]\d{7}|9\d{8})$/.test(d)?'':'Informe um WhatsApp brasileiro válido, com DDD e número.');}
phoneInput.addEventListener('input',()=>{phoneInput.value=formatPhone(phoneInput.value);validatePhone();});
for(const field of contactForm.querySelectorAll('input:not([name="website"]),textarea')){
 field.addEventListener('invalid',()=>field.setAttribute('aria-invalid','true'));
 field.addEventListener('input',()=>field.removeAttribute('aria-invalid'));
}
async function checkService(){
 try{
  if(location.protocol==='file:')return;
  const response=await fetch(contactForm.getAttribute('action'),{headers:{Accept:'application/json'},cache:'no-store',signal:AbortSignal.timeout(8000)});
  const data=await response.json();ready=response.ok&&data.ready===true;
 }catch{ready=false;}
 sendButton.disabled=!ready;
 availability.hidden=ready;
}
checkService();
contactForm.addEventListener('submit',async event=>{
 event.preventDefault();if(inFlight)return;
 validatePhone();
 if(!contactForm.reportValidity())return;
 if(!ready){setStatus('O envio por e-mail ainda não está disponível. Utilize o Instagram profissional.','error');return;}
 const fields=new FormData(contactForm);
 const message={name:String(fields.get('name')).trim(),email:String(fields.get('email')).trim(),phone:phoneDigits(String(fields.get('phone'))),message:String(fields.get('message')).trim(),website:String(fields.get('website')||'')};
 const serialized=JSON.stringify(message);
 if(serialized!==pendingPayload){pendingPayload=serialized;pendingKey=crypto.randomUUID?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');}
 inFlight=true;sendButton.disabled=true;sendButton.setAttribute('aria-busy','true');sendLabel.textContent='Enviando…';contactForm.setAttribute('aria-busy','true');setStatus('Enviando sua mensagem.');
 try{
  const response=await fetch(contactForm.getAttribute('action'),{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json','Idempotency-Key':pendingKey},body:JSON.stringify({...message,startedAt}),signal:AbortSignal.timeout(16000)});
  const data=await response.json();
  if(!response.ok||data.sent!==true)throw new Error(data.error||'Não foi possível confirmar o envio. Tente novamente.');
  setStatus('Mensagem enviada ao serviço de e-mail. Obrigada pelo contato.','success');contactForm.reset();pendingPayload='';pendingKey='';startedAt=Date.now();
 }catch(error){
  const timeout=error.name==='TimeoutError'||error.name==='AbortError';
  setStatus(timeout?'Não foi possível confirmar o envio a tempo. Aguarde e tente novamente; sua mensagem foi preservada.':(error.message==='Failed to fetch'?'Não foi possível conectar ao serviço. Sua mensagem foi preservada. Tente novamente.':error.message),'error');
 }finally{inFlight=false;sendButton.disabled=!ready;sendButton.removeAttribute('aria-busy');contactForm.removeAttribute('aria-busy');sendLabel.textContent='Enviar mensagem';}
});
