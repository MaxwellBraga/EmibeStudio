'use strict';
const {createHash}=require('node:crypto');
const RATE_WINDOW=10*60*1000,MAX_ATTEMPTS=5,MAX_BODY=12000;
const attempts=new Map();
const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const result=(status,body,extra={})=>({status,headers:{...headers,...extra},body});
const emailValid=value=>typeof value==='string'&&value.length<=254&&!/[\r\n\x00-\x1f\x7f]/.test(value)&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
function configuration(env){
 const from=(env.CONTACT_FROM_EMAIL||'').trim(),to=(env.CONTACT_TO_EMAIL||'').trim();
 const match=from.match(/<([^<>]+)>$/),fromAddress=match?match[1]:from;
 let origin='';try{const site=new URL(env.PUBLIC_SITE_URL);if(site.protocol==='https:'||site.protocol==='http:')origin=site.origin;}catch{}
 const ready=env.CONTACT_ENABLED==='true'&&!!env.RESEND_API_KEY&&emailValid(to)&&emailValid(fromAddress)&&!/\r|\n/.test(from)&&!!origin;
 return {ready,origin,from,to};
}
function allowAttempt(ip,now){
 for(const [key,value] of attempts)if(value.until<=now)attempts.delete(key);
 const key=createHash('sha256').update(ip||'unknown').digest('hex');
 const current=attempts.get(key)||{count:0,until:now+RATE_WINDOW};
 if(current.count>=MAX_ATTEMPTS)return false;
 current.count++;
 if(attempts.size>=2000&&!attempts.has(key))return false;
 attempts.set(key,current);return true;
}
function validate(raw,now){
 if(!raw||typeof raw!=='object'||Array.isArray(raw))return null;
 if(raw.website!==undefined&&(typeof raw.website!=='string'||raw.website.trim()))return null;
 const fields=['name','email','phone','message'];if(fields.some(k=>typeof raw[k]!=='string'))return null;
 const name=raw.name.trim(),email=raw.email.trim(),message=raw.message.replace(/\r\n?/g,'\n').trim();
 let phone=raw.phone.replace(/[() +.-]/g,'');if(phone.startsWith('55')&&phone.length>11)phone=phone.slice(2);
 if(name.length<3||name.length>100||/[\x00-\x1f\x7f]/.test(name)||!emailValid(email)||!/^([1-9]{2})([2-9]\d{7}|9\d{8})$/.test(phone)||message.length<10||message.length>3000||/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(message))return null;
 if(!Number.isFinite(raw.startedAt)||now-raw.startedAt<2000||now-raw.startedAt>24*60*60*1000)return null;
 return {name,email,phone,message};
}
async function handleContact(request,{env=process.env,fetchImpl=fetch,now=Date.now()}={}){
 const config=configuration(env);
 if(request.method==='GET')return result(200,{ready:config.ready});
 if(request.method!=='POST')return result(405,{error:'Método não permitido.'},{Allow:'GET, POST'});
 // Fail closed: only requests from the configured site may send mail.
 if(!config.ready)return result(503,{error:'O envio por e-mail está em configuração. Utilize o Instagram profissional.'});
 if(request.origin!==config.origin)return result(403,{error:'Não foi possível validar a origem do contato.'});
 if(!String(request.contentType||'').toLowerCase().startsWith('application/json'))return result(415,{error:'Formato de envio inválido.'});
 if(!allowAttempt(request.ip,now))return result(429,{error:'Muitas tentativas. Aguarde alguns minutos antes de tentar novamente.'},{'Retry-After':'600'});
 const key=request.idempotencyKey;
 if(typeof key!=='string'||!/^[-a-zA-Z0-9_]{16,100}$/.test(key))return result(400,{error:'Identificador de envio inválido. Atualize a página.'});
 let raw=request.body;
 try{
  const text=typeof raw==='string'?raw:JSON.stringify(raw);
  if(Buffer.byteLength(text||'','utf8')>MAX_BODY)return result(413,{error:'A mensagem excede o limite permitido.'});
  raw=typeof raw==='string'?JSON.parse(raw):raw;
 }catch{return result(400,{error:'Não foi possível ler os dados enviados.'});}
 const data=validate(raw,now);
 if(!data)return result(400,{error:'Revise nome, e-mail, WhatsApp e mensagem antes de enviar.'});
 try{
  const response=await fetchImpl('https://api.resend.com/emails',{
   method:'POST',headers:{Authorization:'Bearer '+env.RESEND_API_KEY,'Content-Type':'application/json','Idempotency-Key':'ananias-contact/'+key},
   body:JSON.stringify({from:config.from,to:[config.to],reply_to:data.email,subject:'Novo contato — Ananias Salute',text:`Nome: ${data.name}\nE-mail: ${data.email}\nWhatsApp: +55${data.phone}\n\nMensagem:\n${data.message}`}),
   signal:AbortSignal.timeout(10000)
  });
  let receipt;try{receipt=await response.json();}catch{return result(502,{error:'Não foi possível confirmar o envio. Tente novamente.'});}
  if(!response.ok||typeof receipt.id!=='string'||!receipt.id)return result(502,{error:'O serviço de e-mail não confirmou o envio. Tente novamente.'});
  // A provider receipt confirms acceptance, not arrival in the recipient's inbox.
  return result(200,{sent:true});
 }catch{return result(502,{error:'Não foi possível confirmar o envio. Sua mensagem pode ser reenviada com segurança.'});}
}
module.exports={handleContact};
