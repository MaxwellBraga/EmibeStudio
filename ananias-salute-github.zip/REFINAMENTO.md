# Refinamento visual da versão existente

## Fotografias utilizadas

| Seção | Origem |
| --- | --- |
| Hero | Retrato profissional com braços cruzados.png; camisa branca, arquivo oficial transparente. |
| Sobre | Retrato profissional feminino em fundo transparente.png; aplicado por solicitação posterior, com blazer preto e camisa branca. |
| Cuidado e Gestão | 25629267-e423-42d0-afbe-48770e53cf39.png; substituiu o recorte de baixa resolução da apresentação. |
| Formação e Trajetória | Retrato de blazer branco e blusa azul, recortado da referência oficial; original separado não disponível. |
| Cards | Fotografias de auditoria, corredor hospitalar e mãos em cuidado, recortadas da referência oficial. |

A fotografia de Sobre foi substituída pelo retrato oficial de blazer preto, por solicitação explícita da cliente. Foram adicionadas as versões sobre-oficial-480.webp e sobre-oficial-800.webp.

Não foram gerados rostos, fotografias ou alterações de tonalidade.

## Alterações desta revisão

- index.html: fotografia de apresentação em resolução maior, srcset responsivo e curva SVG escalável para as transições.
- premium.css: alturas e espaçamentos desktop aproximados ao modelo, proporções da hero, foto integrada ao fundo de Cuidado e Gestão, overlays dos cards, acabamento dourado nas curvas e ajustes para tablet/mobile.
- assets/apresentacao-oficial-640.webp, apresentacao-oficial-960.webp e apresentacao-oficial-1254.webp: imagens novas.
- LEIA-ME.md, creditos-fotograficos.txt e este relatório: origem dos arquivos e limitações atualizadas.

O restante do código funcional, fontes e marca existente foram preservados.

## Comparação e limites

A referência é um mockup rasterizado de 992 × 1586 px. Foram capturadas as páginas completas em 360, 390, 430, 768, 1024 e 1440 px, comparadas visualmente com a referência e refinadas em seguida.

A versão desktop ficou mais próxima na sequência e altura das faixas, na composição das três colunas da hero, nos cards com overlay e nas transições suaves. Mantém algum espaço adicional para a qualificação FGV completa já aprovada e para a legibilidade.

Arquivos ainda ausentes:

2. Original separado do retrato de blazer branco e blusa azul, utilizado em Formação e Trajetória.
3. Originais separados das três imagens dos cards de auditoria, hospital e cuidado paliativo.
4. Logo oficial SVG ou PNG com transparência real, sem quadriculado incorporado.

Os recortes da referência continuam em uso nos quatro recursos sem original separado, com limitação de nitidez e de integração ao fundo. A foto oficial de apresentação tem gesto e ambiente diferentes dos do mockup; ambos foram preservados. Mantida a versão transparente da logo já existente, que difere do monograma TA mostrado no mockup. O fundo da hero preserva o verde e as linhas discretas, sem plantas, conforme a instrução anterior.

## Validação

As seis larguras passaram sem rolagem horizontal, imagens ou fontes quebradas, âncoras inválidas ou erros JavaScript. Verificados menu mobile, Escape, privacidade, pausa e retomada do marquee e movimento reduzido.

Para visualizar: abrir index.html ou a prévia http://127.0.0.1:8765/. Site estático sem build; não publicado.
