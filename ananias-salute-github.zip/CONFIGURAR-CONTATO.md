# Configuração do contato

O envio está desativado até configurar e validar o endereço oficial. Não há credenciais no navegador nem banco de dados de mensagens.

## Publicação

O pacote contém adaptadores para Netlify e Vercel. Na Netlify, publique pelo repositório ou CLI com suporte a Functions; um upload estático por arrastar e soltar não instala a API. Na Vercel, use projeto estático com Functions Node.js. Não publique arquivos `.env` reais. O arquivo `.env.example` contém apenas nomes e valores vazios.

Configure no painel de variáveis do provedor:

- `CONTACT_ENABLED=true`, somente quando tudo estiver configurado.
- `RESEND_API_KEY`: chave privada do Resend.
- `CONTACT_FROM_EMAIL`: remetente autorizado no domínio verificado, por exemplo `Ananias Salute <endereco@dominio-oficial>`; substitua pelo endereço real.
- `CONTACT_TO_EMAIL`: e-mail oficial que receberá os contatos.
- `PUBLIC_SITE_URL`: URL pública exata, incluindo https. Origens de prévia precisam de sua própria configuração.

Publique novamente após alterar variáveis. `GET /api/contact` deve responder `{"ready":true}`. Isso confirma configuração, não entrega de e-mail.

## Validação obrigatória antes de liberar

Enviar pelo formulário uma mensagem autorizada de teste, verificar recebimento no endereço oficial e resposta ao remetente, testar falha do provedor e envio repetido. Uma confirmação da API significa aceitação pelo serviço; não garante chegada à caixa de entrada. Até realizar esse teste real, o envio não está homologado.

A API valida origem, tamanho, campos, telefone, tempo de preenchimento, honeypot e idempotência. Limita cinco tentativas por dez minutos por identificador de IP transformado em hash. O limite em memória é por instância aquecida, não global: configure também proteção e limite de requisições no provedor antes de exposição pública. A API não registra conteúdo ou dados de contato em logs. Revise a política de privacidade oficial e as condições de tratamento e retenção do serviço de e-mail.

Os cinco textos do FAQ são provisórios conforme o briefing e precisam de aprovação da cliente. Nenhum contato profissional foi inventado; o Instagram existente foi preservado.

## Arquivos

Interface: index.html, contact.css, contact.js. API compartilhada: server/contact.cjs. Adaptadores: api/contact.js e netlify/functions/contact.cjs. Configuração: netlify.toml, vercel.json, .env.example.

## Referências oficiais

- https://resend.com/docs/api-reference/emails/send-email
- https://resend.com/docs/dashboard/emails/idempotency-keys
- https://docs.netlify.com/build/functions/lambda-compatibility/
- https://vercel.com/docs/functions/runtimes/node-js
