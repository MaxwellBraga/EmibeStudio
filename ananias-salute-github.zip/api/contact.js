'use strict';
const {handleContact}=require('../server/contact.cjs');
module.exports=async function contact(req,res){
 const answer=await handleContact({method:req.method,origin:req.headers.origin,contentType:req.headers['content-type'],ip:(req.headers['x-forwarded-for']||req.socket?.remoteAddress||'').split(',')[0].trim(),idempotencyKey:req.headers['idempotency-key'],body:req.body});
 for(const [name,value] of Object.entries(answer.headers))res.setHeader(name,value);
 res.status(answer.status).json(answer.body);
};
